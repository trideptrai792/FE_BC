export default function UserPage() {
    return (
      <div>
        <h2 className="text-xl font-bold mb-4">User List</h2>
        <div className="bg-white p-4 rounded shadow">
          <p>Danh sách user sẽ hiển thị ở đây</p>
        </div>
      </div>
    );
  }
  