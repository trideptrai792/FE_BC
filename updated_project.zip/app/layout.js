
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata = {
  title: "E-Commerce Shop",
  description: "An online store with amazing products.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable}`}>
        <header className="bg-blue-600 text-white p-4 flex justify-between items-center">
          <div className="font-semibold text-xl">ShopLogo</div>
          <nav>
            <ul className="flex space-x-6">
              <li><a href="/" className="hover:text-gray-300">Home</a></li>
              <li><a href="/products" className="hover:text-gray-300">Products</a></li>
              <li><a href="/login" className="hover:text-gray-300">Login</a></li>
            </ul>
          </nav>
        </header>
        <main>{children}</main>
        <footer className="bg-blue-600 text-white text-center p-4 mt-12">
          <p>&copy; 2025 E-Commerce Shop. All rights reserved.</p>
        </footer>
      </body>
    </html>
  );
}
