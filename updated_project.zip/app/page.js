
export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-blue-400 to-indigo-600 text-white p-6">
      <h1 className="text-5xl font-bold mb-6">Welcome to Our Website!</h1>
      <p className="text-xl max-w-xl text-center mb-8">Find amazing products for all your needs!</p>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white text-gray-800 p-4 rounded-lg shadow-lg">
          <h2 className="font-semibold text-xl mb-4">Product 1</h2>
          <p className="text-lg mb-4">Description of Product 1.</p>
          <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-500">Buy Now</button>
        </div>
        <div className="bg-white text-gray-800 p-4 rounded-lg shadow-lg">
          <h2 className="font-semibold text-xl mb-4">Product 2</h2>
          <p className="text-lg mb-4">Description of Product 2.</p>
          <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-500">Buy Now</button>
        </div>
        <div className="bg-white text-gray-800 p-4 rounded-lg shadow-lg">
          <h2 className="font-semibold text-xl mb-4">Product 3</h2>
          <p className="text-lg mb-4">Description of Product 3.</p>
          <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-500">Buy Now</button>
        </div>
      </div>
    </main>
  );
}
