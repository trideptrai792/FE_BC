// app/product/page.js
const products = [
    { id: 1, name: "Product A", price: 29.99 },
    { id: 2, name: "Product B", price: 49.99 },
    { id: 3, name: "Product C", price: 19.99 },
  ];
  
  export default function ProductPage() {
    return (
      <main className="min-h-screen p-8 bg-gray-100">
        <h1 className="text-4xl font-bold mb-6">Our Products</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {products.map((product) => (
            <div key={product.id} className="bg-white rounded shadow p-6">
              <h2 className="text-xl font-semibold mb-2">{product.name}</h2>
              <p className="text-indigo-600 font-bold text-lg">${product.price.toFixed(2)}</p>
              <button className="mt-4 bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 transition">
                Add to Cart
              </button>
            </div>
          ))}
        </div>
      </main>
    );
  }
  