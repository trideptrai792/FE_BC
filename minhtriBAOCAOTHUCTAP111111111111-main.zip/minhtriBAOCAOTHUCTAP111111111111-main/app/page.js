export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-blue-400 to-indigo-600 text-white p-6">
      <h1 className="text-5xl font-bold mb-6">Welcome to Our Website!</h1>
      <p className="text-xl max-w-xl text-center mb-8">
        Explore our products, posts, and user dashboard. Enjoy your stay!
      </p>
      <div className="space-x-4">
        <a
          href="/product"
          className="px-6 py-3 bg-white text-indigo-600 font-semibold rounded shadow hover:bg-gray-200 transition"
        >
          View Products
        </a>
        <a
          href="/post"
          className="px-6 py-3 border border-white font-semibold rounded hover:bg-white hover:text-indigo-600 transition"
        >
          Read Posts
        </a>
      </div>
    </main>
  );
}
