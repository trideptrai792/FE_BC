export default function AdminIndex() {
    return (
      <div className="p-6">
        <h1 className="text-3xl font-bold">Welcome to Admin Dashboard</h1>
        <p>Chọn menu bên trái để bắt đầu.</p>
      </div>
    );
  }
  